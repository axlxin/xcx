ATmega64

16x2 LCD Connection

PA0 - D0
PA1 - D1
PA2 - D2
PA3 - D3
PA4 - D4
PA5 - D5
PA6 - D6
PA7 - D7
PC0 - RS
PC1 - RW
PC2 - E