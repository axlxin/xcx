This is an Arduino library for the Eink to display picture and string. 
Features:
1.Display a full picture(3096 bytes,172*72).
2.Display a half resolution of a full picture(1548 bytes,172*72).
3.Display a string("0-9,a-z,A-Z,~!@#$....")
Author:Bruce Guo(NOA Labs)
Copyright (C) 2016 by NOA Labs
2016-3-2