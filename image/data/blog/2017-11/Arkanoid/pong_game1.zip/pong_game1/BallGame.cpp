#include <Adafruit_GFX.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_NeoMatrix.h>
#include "BallGame.h"

//Brick::Brick(int cornerX, int cornerY) {
//  Serial.println("Initializing brick");
//  x = cornerX;
//  y = cornerY;
//
//}
//
//Brick::Brick() {
//
//}
//
//BrickArray::BrickArray() {
//
//}
//
//void BrickArray::init() {
//  Serial.println("Initializing brick array");
//  for (int i = 0; i < 4 ; i++) {
//    for (int j = 0; j < 8; j++) {
//      brickPs[i][j] = new Brick(i*4,j*2);
//
//    }
//  }
//
//}

//Paddle::Paddle(int w) {
//  width = w;
//}

//Ball::Ball() {
//
//
//}

//Ball::Ball(int startX, int startY) {
//
//
//}

BallGame::BallGame(Adafruit_NeoMatrix* thisMatrix) {
  neonMatrix = thisMatrix;

}

void BallGame::updateGame(int paddleCenter) {

  this->neonMatrix->writePixel(5, 5, neonMatrix->Color(255, 0, 255));
  this->neonMatrix->drawLine(paddleCenter - 2, 23, paddleCenter + 2, 23, neonMatrix->Color(255, 255, 255));
  //drawBricks();

}

