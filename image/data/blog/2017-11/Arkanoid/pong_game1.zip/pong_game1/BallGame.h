#ifndef BallGame_h
#define BallGame_h
#endif
#if ARDUINO >= 100
#include <Arduino.h>
#else
#include <WProgram.h>
#include <pins_arduino.h>
#endif

//class Brick {
//
//  public:
//
//    Brick();
//    Brick(int cornerX, int cornerY);
//    int x;
//    int y;
//    
//};
//
//class BrickArray {
//
//  public:
//
//    BrickArray();
//
//    Brick* brickPs[8][4];
//
//    void init();
//
//    void draw();
//  
//};

//class Paddle {
//
//  public:
//    Paddle(int w);
//    int delta;
//    int lastPosition;
//    int center;
//    int width;
//
//};

//class Ball {
//
//  public:
//
//    Ball();
//    Ball(int startX, int startY);
//    uint8_t vX = 0;
//    uint8_t vY = 0;
//    void deflect();
//    
//};

class BallGame {

  public:

    BallGame(Adafruit_NeoMatrix *thisMatrix);//, Paddle *pPaddle);//, Ball *pBall); // BrickArray* pBricks, Ball *pBall);
    Adafruit_NeoMatrix* neonMatrix;
 //   Paddle* paddle;
    void updateGame(int paddleCenter);
 //   void drawBricks();
    uint8_t numPlayers;
  //  BrickArray* bricks;
  //  Ball* ball;

    
};

